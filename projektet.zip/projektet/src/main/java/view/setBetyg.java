package view;

public class setBetyg {
    
}
